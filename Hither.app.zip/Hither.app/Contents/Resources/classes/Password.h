//
//  Password.h
//  
//
//  Created by Sterling  on 18/07/2016.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface Passwordr : NSManagedObject
@property NSString *passa;

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "Password+CoreDataProperties.h"
