//
//  Tips View.h
//  hitherrr
//
//  Created by Sterling  on 18/07/2016.
//  Copyright © 2016 Sterling . All rights reserved.
//
#import <AppKit/AppKit.h>
#import <Cocoa/Cocoa.h>
#import <Foundation/Foundation.h>


@interface Tips_View : NSTextView
@property IBInspectable NSColor *color;
@property IBInspectable NSString *striger;
@property IBInspectable
@package IBInspectable BOOL Yers;



@end
