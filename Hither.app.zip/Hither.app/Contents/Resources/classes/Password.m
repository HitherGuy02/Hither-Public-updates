//
//  Password.m
//  
//
//  Created by Sterling  on 18/07/2016.
//
//

#import "Password.h"

@implementation Passwordr

// Insert code here to add functionality to your managed object subclass

@end
