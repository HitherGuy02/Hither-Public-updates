//
//  Password+CoreDataProperties.m
//  
//
//  Created by Sterling  on 18/07/2016.
//
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Password+CoreDataProperties.h"

@implementation Passwordr (CoreDataProperties)

@dynamic boolutoo;
@dynamic password;

@end
