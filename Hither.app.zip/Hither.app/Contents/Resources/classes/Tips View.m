//
//  Tips View.m
//  hitherrr
//
//  Created by Sterling  on 18/07/2016.
//  Copyright © 2016 Sterling . All rights reserved.
//

#import "Tips View.h"

@implementation Tips_View

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

@end
